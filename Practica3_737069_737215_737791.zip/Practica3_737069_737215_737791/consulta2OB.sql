SELECT V.ID_AVION,ANYO,ORIGEN,Avg(ANYO)
                                OVER (
                                  PARTITION BY ORIGEN
                                  ORDER BY ANYO) MEDIA
FROM   (SELECT ORIGEN,ID_AVION
        FROM   VUELO
               INNER JOIN AEROPUERTO
                       ON ORIGEN = ID_AEROPUERTO) V
       INNER JOIN AVION A
               ON V.ID_AVION = A.ID_AVION
WHERE  ANYO != 0
ORDER  BY MEDIA; 
