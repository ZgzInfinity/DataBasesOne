
-- vista con todos los vuelos retrasados a la salida, llegada, o ambos
create view vuelos_retrasados 
as (
   select id_vuelo, id_empresa, hora_llegada_real, hora_llegada, hora_salida_real, hora_salida
   from vuelo
   where (hora_llegada_real > hora_llegada and hora_salida_real <= hora_salida)
	 or
	 (hora_salida_real > hora_salida and hora_llegada_real <= hora_llegada)
	 or
	 (hora_llegada_real > hora_llegada and hora_salida_real > hora_salida)
);

-- vista que relaciona los vuelos atrasados con la empresa que los gestiona
create view vuelos_atrasados
as (
   select E.nombre_empresa as nombre,
          VR.hora_llegada_real as llegada_real
	  ,VR.hora_llegada as llegada
	  ,VR.hora_salida_real as salida_real
	  ,VR.hora_salida as salida
   from empresa E inner join vuelos_retrasados VR
   on E.id_empresa = VR.id_empresa
);

-- para cada empresa se muestra el importe medio a pagar por cada vuelo retrasado
-- por cada vuelo retrasado a la llegada debe abonar 25
-- por cada vuelo retrasado a la salida debe abonar 35
-- por cada vuelo atrasado en ambas debe abonar 60
select nombre, sum(pago) as cuantia_deuda
from (
     select nombre, llegada_real, llegada, salida_real, salida,
     case
	 when llegada_real > llegada and salida_real <= salida then 25
	 when salida_real > salida and llegada_real <= llegada then 35
	 when llegada_real > llegada and salida_real > salida then 60
	 else 0
	 end as pago
     from vuelos_atrasados 
)
group by nombre
order by cuantia_deuda asc;


-- eliminación de las vistas
drop view vuelos_retrasados;
drop view vuelos_atrasados;

	  

