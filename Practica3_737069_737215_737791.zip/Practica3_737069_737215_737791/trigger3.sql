--Si el avión se retrasa más de una hora salta un error

CREATE OR REPLACE TRIGGER avion_retrasado
   AFTER UPDATE ON RETRASOS
   FOR EACH ROW
BEGIN
   if (:OLD.retraso_avion > 60)
      RAISE_APPLICATION_ERROR(-20343,'El tiempo de espera del avión ha superado el máximo');
   END IF;
   END avion_retrasado