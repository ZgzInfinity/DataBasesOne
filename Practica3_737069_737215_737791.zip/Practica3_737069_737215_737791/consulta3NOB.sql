
-- vista con todos los vuelos cancelados
create view vuelos_eliminados
as (
   select id_empresa, count(id_vuelo) as vuelos_cancelados
   from (
	select id_vuelo, id_empresa
	from vuelo
	where cancelado = '1'
   )
   group by id_empresa
);

-- vista con todos los vuelos desviados
create view vuelos_modificados
as (
   select id_empresa, count(id_vuelo) as vuelos_desviados
   from (
	select id_vuelo, id_empresa
	from vuelo
	where cancelado = '1'
   )
   group by id_empresa
);

-- vista que relaciona cada vuelo cancelado con su empresa
create view vuelos_cancelados_empresa
as (
   select E.nombre_empresa, VE.vuelos_cancelados
   from empresa E, vuelos_eliminados VE
   where E.id_empresa = VE.id_empresa
);


-- vista que relaciona cada vuelo desviado con su empresa
create view vuelos_desviados_empresa
as (
   select E.nombre_empresa, VM.vuelos_desviados
   from empresa E, vuelos_modificados VM
   where E.id_empresa = VM.id_empresa
);


-- muestra para cada compañía aérea cuantos vuelos han sido cancelados y cuántos desviados
select A.nombre_empresa, A.vuelos_desviados, B.vuelos_cancelados
from vuelos_desviados_empresa A, vuelos_cancelados_empresa B
where A.nombre_empresa = B.nombre_empresa;


-- eliminación de las vistas
drop view vuelos_eliminados;
drop view vuelos_modificados;
drop view vuelos_cancelados_empresa;
drop view vuelos_desviados_empresa;

