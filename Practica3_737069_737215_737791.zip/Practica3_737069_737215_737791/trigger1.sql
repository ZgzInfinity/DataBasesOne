--Cambio de empresa con la que se vuela

CREATE OR REPLACE TRIGGER cambio_empresa
	AFTER UPDATE ON empresa
	FOR EACH ROW
begin
	if (:OLD.ID_EMPRESA <> :NEW.ID_EMPRESA)
		then INSERT INTO empresa VALUES (:NEW.ID_EMPRESA, :NEW.NOMBRE_EMPRESA);
	end if;
	end cambio_empresa