--Cambio de avion con el que se vuela

CREATE OR REPLACE TRIGGER cambio_avion
   AFTER UPDATE ON avion 
   FOR EACH ROW
begin
   if (:OLD.ID_AVION <> :NEW.ID_AVION)
      then INSERT INTO avion VALUES (:NEW.ID_AVION, :NEW.ANYO);
   end if;
   end cambio_avion