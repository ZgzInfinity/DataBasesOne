
-- Vista con todos los vuelos que han experimentado retrasos en la salida y en la llegada
create view vuelos_problematicos
as (
    select V.id_empresa, E.nombre_empresa, V.id_vuelo, V.hora_salida_real, V.hora_salida, V.hora_llegada_real, V.hora_llegada
    from Vuelo V, Empresa E
    where (hora_salida_real  > hora_salida  and hora_llegada_real > hora_llegada)
	   and
	   (V.id_empresa = E.id_empresa)
);

-- Vista con las medias de retrasos de salida y de llegada para cada compañia aérea
create view promedio_retrasos
as (
    select id_empresa, nombre_empresa, avg(retra_sal) as media_retrasos_salida, avg(retra_lleg) as media_retrasos_llegada
    from (
	  select id_empresa, nombre_empresa, (hora_salida_real - hora_salida) as retra_sal, (hora_llegada_real - hora_llegada) as retra_lleg
	  from vuelos_problematicos
    )
    group by (id_empresa, nombre_empresa)
);

-- vista con las empresas que han gestionado más de 1000 vuelos cada día
create view empresas_potentes
as (
    select id_empresa, fecha, vuelos_por_dia
    from (
	 select id_empresa, fecha, count(fecha) as vuelos_por_dia 
	 from vuelo
	 group by (id_empresa, fecha)
    )
    where (fecha = '25/10/2008' and vuelos_por_dia >= 1000)
	  or 
	  (fecha = '26/10/2008' and vuelos_por_dia >= 1000)
	  or
	  (fecha = '27/10/2008' and vuelos_por_dia >= 1000)
);

-- Selección de las compañías aereas con más de 1000 vuelos cada día junto con su media de retrasos de salida y 
--llegada ordenados por retrasos de salida 
select distinct PR.id_empresa, PR.nombre_empresa, PR.media_retrasos_salida, PR.media_retrasos_llegada
from promedio_retrasos PR, empresas_potentes EP
where PR.id_empresa = EP.id_empresa
order by PR.media_retrasos_salida desc;

-- eliminación de vistas
drop view vuelos_problematicos;
drop view promedio_retrasos;
drop view empresas_potentes;
