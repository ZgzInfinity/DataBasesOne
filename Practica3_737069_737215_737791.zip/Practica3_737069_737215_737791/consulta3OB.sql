
-- vista con los estados de origen, destino y la empresa coordinadora
create view vuelos_empresa
as (
   select V.id_vuelo, V.origen, V.destino, E.nombre_empresa 
   from Vuelo V inner join Empresa E
   on V.id_empresa = E.id_empresa
);

-- vista con los vuelos y el estado de origen
create view vuelos_estado_origen
as (
   select VE.id_vuelo, VE.nombre_empresa, A.estado
   from vuelos_empresa VE inner join aeropuerto A
   on VE.origen = A.id_aeropuerto
);

-- vista con los vuelos y el estado de destino
create view vuelos_estado_destino
as (
   select VE.id_vuelo, VE.nombre_empresa, A.estado
   from vuelos_empresa VE inner join aeropuerto A
   on VE.destino = A.id_aeropuerto
);

-- selección de todos los vuelos que han despegado y aterrizado en el mismo estado
-- se muestra la empresa coordinadora, los estados de origen y destino, y el porcentaje 
select nombre_corporativa, estado_origen, estado_destino, ((count(estado_destino) * 100) / (select count(*) from vuelo)) as porcentaje
from (
     select VEO.nombre_empresa as nombre_corporativa, VEO.estado as estado_origen, VED.estado as estado_destino
     from vuelos_estado_origen VEO, vuelos_estado_destino VED
     where VEO.id_vuelo = VED.id_vuelo and VEO.estado = VED.estado
)
group by (nombre_corporativa, estado_origen, estado_destino)
order by porcentaje desc;

-- eliminación de las vistas
drop view vuelos_empresa;
drop view vuelos_estado_origen;
drop view vuelos_estado_destino;
