
-- vista con todos los vuelos cancelados
create view vuelos_cancelados
as (
   select id_vuelo, id_avion
   from vuelo
   where cancelado = '1'
);

-- vista con los vuelos que ha realizado cada avion
create view vuelos_cancelados_avion
as (
   select A.id_avion, VC.id_vuelo
   from Avion A inner join vuelos_cancelados VC
   on A.id_avion = VC.id_avion
);

-- porcentaje de vuelos cancelados para cada avion con respecto al total de vuelos cancelados
select id_avion, ((count(id_avion) * 100) / (select count(*) from vuelos_cancelados_avion)) as porcentaje_vuelos_cancelados
from vuelos_cancelados_avion
group by id_avion
order by porcentaje_vuelos_cancelados desc;


-- eliminaci�n de las vistas
drop view vuelos_cancelados;
drop view vuelos_cancelados_avion;
