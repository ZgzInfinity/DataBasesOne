CREATE TABLE DIVISION
  (
     numero VARCHAR(16) PRIMARY KEY
  );

CREATE TABLE LIGA
  (
     temporada VARCHAR(16) PRIMARY KEY,denominacion_oficial VARCHAR(16) NOT NULL
  );

CREATE TABLE JORNADA
  (
     id_jornada VARCHAR(16) PRIMARY KEY,anyo VARCHAR(16) NOT NULL,
     FOREIGN KEY(anyo) REFERENCES LIGA(temporada) ON DELETE CASCADE
  );

CREATE TABLE EQUIPO_ESTADIO
  (
     nombre_corto VARCHAR(128) PRIMARY KEY,nombre_oficial VARCHAR(128),
     nombre_historico VARCHAR(128),fundacion VARCHAR(16),ciudad VARCHAR(26),
     estadio VARCHAR(34) NOT NULL,capacidad NUMBER(6, 0),
     inauguracion VARCHAR(16),
     CONSTRAINT EQ_EST UNIQUE (estadio)
  );

CREATE TABLE PARTIDO
  (
     id_partido NUMBER(8, 0) PRIMARY KEY,jornada VARCHAR(16) NOT NULL,division
     VARCHAR(16) NOT NULL,equipo_local VARCHAR(128) NOT NULL,
     equipo_visitante VARCHAR(128) NOT NULL,goles_local NUMBER(3, 0),
     goles_visitante NUMBER(3, 0),
     FOREIGN KEY(equipo_local) REFERENCES EQUIPO_ESTADIO(nombre_corto) ON DELETE
     CASCADE,
     FOREIGN KEY(equipo_visitante) REFERENCES EQUIPO_ESTADIO(nombre_corto) ON
     DELETE CASCADE,
     FOREIGN KEY(division) REFERENCES DIVISION(numero) ON DELETE CASCADE,
     FOREIGN KEY(jornada) REFERENCES JORNADA(id_jornada) ON DELETE CASCADE
  ); 
