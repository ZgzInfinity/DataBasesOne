SELECT bytes / 1024 KB
FROM   USER_SEGMENTS
WHERE  segment_name = 'PARTIDO';

SELECT bytes / 1024 KB
FROM   USER_SEGMENTS
WHERE  segment_name = 'EQUIPO_ESTADIO';

SELECT bytes / 1024 KB
FROM   USER_SEGMENTS
WHERE  segment_name = 'JORNADA';

SELECT bytes / 1024 KB
FROM   USER_SEGMENTS
WHERE  segment_name = 'DIVISION';

SELECT bytes / 1024 KB
FROM   USER_SEGMENTS
WHERE  segment_name = 'LIGA'; 
