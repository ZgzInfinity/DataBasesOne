-- Devuelve los estadios donde más PARTIDO se han ceñebrado de primera división
SELECT estadio,anyo,Count(estadio) AS VECES
FROM   (SELECT jornada,estadio
        FROM   PARTIDO
               INNER JOIN EQUIPO_ESTADIO
                       ON nombre_corto = equipo_local
        WHERE  division = 1)
       INNER JOIN JORNADA
               ON id_jornada = jornada
GROUP  BY estadio,anyo
ORDER  BY veces DESC; 
