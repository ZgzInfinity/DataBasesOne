-- Para borrar las vistas
DROP VIEW GOLES_VISITANTES;

DROP VIEW GOLES_LOCALES;

DROP VIEW GOLES_TOTALES;

DROP VIEW MENOS_GOLEADORES;

DROP VIEW MAS_GOLEADORES;

-- Esta vista representa los goles que han metido los equipos en su propio estadio
CREATE VIEW GOLES_LOCALES
AS
  SELECT equipo_local,anyo,goles_l
  FROM   (SELECT equipo_local,goles_local,anyo,SUM(goles_local)
                 OVER (
                   PARTITION BY equipo_local, anyo
                 ) AS
                      GOLES_L
          FROM   PARTIDO
                 INNER JOIN JORNADA
                         ON jornada = id_jornada)
  GROUP  BY equipo_local,anyo,goles_l;

-- Esta vista representa los goles que han marcado los equipos en un estadio diferente al suyo
CREATE VIEW GOLES_VISITANTES
AS
  SELECT equipo_visitante,anyo,goles_v
  FROM   (SELECT equipo_visitante,goles_visitante,anyo,
                                SUM(goles_visitante)
                                OVER (
                                  PARTITION BY equipo_visitante,
                                anyo) AS
                                GOLES_V
          FROM   PARTIDO
                 INNER JOIN JORNADA
                         ON jornada = id_jornada)
  GROUP  BY equipo_visitante,anyo,goles_v;

-- Esta vista suma todos los goles que han marcado cada equipo por cada año
CREATE VIEW GOLES_TOTALES
AS
  SELECT equipo_local AS EQUIPO,GOLES_LOCALES.anyo,
         ( goles_v + goles_l ) AS GOLES
  FROM   GOLES_LOCALES
         INNER JOIN GOLES_VISITANTES
                 ON equipo_local = equipo_visitante
                    AND GOLES_LOCALES.anyo = GOLES_VISITANTES.anyo
  ORDER  BY GOLES_LOCALES.anyo;

-- Esta vista contiene la lista de los equipos que menos goles han metido por cada año
CREATE VIEW MENOS_GOLEADORES
AS
  SELECT equipo,goles AS GOLES_MENOS,anyo
  FROM   (SELECT equipo,goles,anyo,Row_number()
                                     OVER (
                                       PARTITION BY anyo
                                       ORDER BY goles ASC) AS RN
          FROM   GOLES_TOTALES)
  WHERE  rn = 1;

-- Esta vista contiene la lista de los equipos que m�s goles han metido por cada año
CREATE VIEW MAS_GOLEADORES
AS
  SELECT equipo,goles AS GOLES_MAS,anyo
  FROM   (SELECT equipo,goles,anyo,Row_number()
                                     OVER (
                                       PARTITION BY anyo
                                       ORDER BY goles DESC) AS RN
          FROM   GOLES_TOTALES)
  WHERE  rn = 1;

-- Se muestran los años que menos diferencia tienen entre el equipo más goleador y el menos goleador, utilizado las dos vistas anteriores
SELECT ( goles_mas - goles_menos ) AS DIFERENCIA,MAS_GOLEADORES.anyo
FROM   MAS_GOLEADORES
       INNER JOIN MENOS_GOLEADORES
               ON MAS_GOLEADORES.anyo = MENOS_GOLEADORES.anyo
ORDER  BY diferencia ASC; 
