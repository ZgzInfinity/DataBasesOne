DROP VIEW ANYO_MEJOR_PORCENTAJE; 

CREATE VIEW ANYO_MEJOR_PORCENTAJE 
AS 
  SELECT anyo 
  FROM   (SELECT anyo,Avg(victorias_locales) * 100 AS PORCENTAJE_LOCALES, 
                 Row_number() 
                                OVER ( 
                                  ORDER BY Avg(victorias_locales)*100) AS RN 
          FROM   (SELECT anyo,CASE 
                                WHEN goles_local > goles_visitante THEN 1 
                                ELSE 0 
                              END AS VICTORIAS_LOCALES 
                  FROM   PARTIDO 
                         INNER JOIN JORNADA 
                                 ON jornada = id_jornada) 
          GROUP  BY anyo) 
  WHERE  rn = 1; 

DROP VIEW ANYO_MEJOR_PORCENTAJE; 

SELECT equipo_local,Avg(victorias_locales) * 100 AS PORCENTAJE_VICTORIA_LOCAL 
FROM   (SELECT equipo_local,jornada,CASE 
                                      WHEN goles_local > goles_visitante THEN 1 
                                      ELSE 0 
                                    END AS VICTORIAS_LOCALES 
        FROM   EQUIPO_ESTADIO 
               INNER JOIN PARTIDO 
                       ON equipo_local = nombre_corto) 
       INNER JOIN JORNADA 
               ON jornada = id_jornada 
WHERE  anyo = (SELECT anyo 
               FROM   ANYO_MEJOR_PORCENTAJE) 
GROUP  BY equipo_local 
ORDER  BY Avg(victorias_locales) * 100 DESC; 