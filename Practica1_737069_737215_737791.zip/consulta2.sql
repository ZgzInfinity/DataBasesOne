-- Se seleccionan los equipos donde el año anterior estaban en una division mayor
-- y se cuentan todas las apariencias por equipo
SELECT equipo_local,Count(equipo_local) AS VECES_CAMBIADO_DIVISION
FROM   (SELECT equipo_local,anyo,division,Lag(division, 1, 0)
                                            OVER (
                                              ORDER BY equipo_local) AS ANT
        FROM   PARTIDO
               INNER JOIN JORNADA
                       ON id_jornada = jornada
        GROUP  BY equipo_local,anyo,division
        ORDER  BY equipo_local)
WHERE  division < ant
GROUP  BY equipo_local
ORDER  BY veces_cambiado_division DESC; 
