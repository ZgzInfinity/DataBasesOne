DROP VIEW GOLES_LOCAL;

DROP VIEW GOLES_VISITANTE;

-- Esta vista representa el número de goles que han marcado los equipos cuyo nombre
-- oficial contiene "Real" entre los años 200 y 1990, en su propio campo
CREATE VIEW GOLES_LOCAL
AS
  SELECT nombre_oficial,SUM(goles_local) AS GOLES
  FROM   (SELECT nombre_oficial,goles_local,anyo
          FROM   (SELECT goles_local,equipo_local,anyo
                  FROM   PARTIDO
                         INNER JOIN JORNADA
                                 ON id_jornada = jornada)
                 INNER JOIN EQUIPO_ESTADIO
                         ON nombre_corto = equipo_local
          WHERE  nombre_oficial LIKE '%Real%'
                 AND anyo < 2000
                 AND anyo > 1990)
  GROUP  BY nombre_oficial
  ORDER  BY goles DESC;

-- Esta vista representa el número de goles que han marcado los equipos cuyo nombre
-- oficial contiene "Real" entre los años 200 y 1990, en un campo diferente al suyo
CREATE VIEW GOLES_VISITANTE
AS
  SELECT nombre_oficial,SUM(goles_visitante) AS GOLES
  FROM   (SELECT nombre_oficial,goles_visitante,anyo
          FROM   (SELECT goles_visitante,equipo_visitante,anyo
                  FROM   PARTIDO
                         INNER JOIN JORNADA
                                 ON id_jornada = jornada)
                 INNER JOIN EQUIPO_ESTADIO
                         ON nombre_corto = equipo_visitante
          WHERE  nombre_oficial LIKE '%Real%'
                 AND anyo < 2000
                 AND anyo > 1990)
  GROUP  BY nombre_oficial
  ORDER  BY goles DESC;

-- Muestra los 10 equipos más goleadores entre 1990 y 2000 cuyo nombre oficial contiene
-- "real"
SELECT nombre,goles_total
FROM   (SELECT nombre,goles_total,Row_number()
                                    OVER (
                                      ORDER BY goles_total DESC) AS RN
        FROM   (SELECT GOLES_LOCAL.nombre_oficial AS NOMBRE,
                       (
                               GOLES_VISITANTE.goles + GOLES_LOCAL.goles
                                                                    ) AS
                       GOLES_TOTAL
                FROM   GOLES_VISITANTE
                       INNER JOIN GOLES_LOCAL
                               ON GOLES_VISITANTE.nombre_oficial =
                                  GOLES_LOCAL.nombre_oficial))
WHERE  rn < 11; 
