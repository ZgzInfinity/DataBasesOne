-- Para el borrado de las tablas
DROP VIEW PUNTUACION_LOCALES;

DROP VIEW PUNTUACION_VISITANTES;

DROP VIEW GANADORES;

-- Esta vista representa la puntuación obtenido por los equipos en su propio estadio
CREATE VIEW PUNTUACION_LOCALES
AS
  SELECT equipo_local,anyo,total_l
  FROM   (SELECT equipo_local,anyo,SUM(puntuacion_l) AS TOTAL_L
          FROM   (SELECT equipo_local,anyo,CASE
                                             WHEN goles_local > goles_visitante
                                           THEN 3
                                             WHEN goles_local = goles_visitante
                                           THEN 1
                                             ELSE 0
                                           END AS puntuacion_l
                  FROM   PARTIDO
                         INNER JOIN JORNADA
                                 ON jornada = id_jornada)
          GROUP  BY equipo_local,anyo);

-- Esta vista representa la puntuación de cada equipo jugando en otro estadio
CREATE VIEW PUNTUACION_VISITANTES
AS
  SELECT equipo_visitante,anyo,total_v
  FROM   (SELECT equipo_visitante,anyo,SUM(puntuacion_v) AS TOTAL_V
          FROM   (SELECT equipo_visitante,anyo,CASE
                                                 WHEN
                         goles_visitante > goles_local THEN
                                                 3
                                                 WHEN
                         goles_visitante = goles_local THEN
                                                 1
                                                 ELSE 0
                                               END AS puntuacion_v
                  FROM   PARTIDO
                         INNER JOIN JORNADA
                                 ON jornada = id_jornada)
          GROUP  BY equipo_visitante,anyo);

-- Esta vista representa los ganadores de la liga de cada a�o obtenido con la suma de las dos vistas anteriores
CREATE VIEW GANADORES
AS
  SELECT equipo_local AS GANADOR
  FROM   (SELECT equipo_local,Row_number()
                                OVER (
                                  PARTITION BY anio
                                  ORDER BY total DESC) AS RN
          FROM   (SELECT equipo_local,PUNTUACION_LOCALES.anyo AS ANIO,
                                 ( total_l + total_v ) AS TOTAL
                  FROM   PUNTUACION_LOCALES
                         INNER JOIN PUNTUACION_VISITANTES
                                 ON PUNTUACION_LOCALES.anyo =
                                    PUNTUACION_VISITANTES.anyo
                                    AND equipo_local = equipo_visitante))
  WHERE  rn = 1;

-- Para terminar la consulta, se cogen a los equipos que no aparecen en la vista de ganadores y han estado en primera división
SELECT DISTINCT equipo_visitante
FROM   PARTIDO
WHERE  division = 1
       AND equipo_visitante NOT IN (SELECT ganador
                                    FROM   GANADORES);
